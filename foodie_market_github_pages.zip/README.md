# Foodie Market｜全球美食 EC 電商平台

這是一個純前端 HTML/CSS/JavaScript 網頁原型，包含：
- 全球美食／店家搜尋介面
- OpenStreetMap 公開地圖資料查詢
- Google 地圖搜尋與路線連結
- 購物車清單（原型，不會實際下單或付款）

## 使用 GitHub Pages 發布公開網站

1. 登入 GitHub，建立一個新的 Repository。
2. Repository 名稱可使用 `foodie-market`。
3. 選擇 Public，建立 Repository。
4. 將本專案中的 `index.html` 上傳至 Repository 根目錄。
5. 開啟 Repository 的 **Settings → Pages**。
6. 在 **Build and deployment** 選擇 **Deploy from a branch**。
7. Branch 選擇 `main`，資料夾選 `/ (root)`，按 **Save**。
8. 等待 GitHub Pages 部署完成，頁面會顯示公開網址，通常格式為：
   `https://你的GitHub帳號.github.io/foodie-market/`

## 注意事項

- 網頁搜尋需要網路連線，並依賴 OpenStreetMap / Overpass 等公開服務；服務可能限流或暫時無法使用。
- 地圖資料不一定包含每家店的即時價格、菜單、評分與營業狀態。
- 購物車目前只是店家清單，尚未實作會員、庫存、真正的訂單、付款或配送。
- 若未來使用 Google Places API 或付款服務，請依服務規範管理 API 金鑰；不要把私密金鑰直接寫進公開前端程式碼。
